import React, { Component } from 'react';

class Controlled extends Component {

    state = {
        name:'',
        lastName:''
    }

    handlenameChange = (event) =>{
        this.setState({
            name:event.target.value
        })
    }

    handleLastnameChange = (event) =>{
        this.setState({
            lastName:event.target.value
        })
    }

    onHandler = (event) =>{
        event.preventDefault();
        console.log(this.state);
    }

    render(){
        return(
            <div className="container">
                <form onSubmit={this.onHandler}>
                    <div className="form-element">
                        <label>
                            EnterName
                        </label>
                        <input type="text" 
                            onChange={this.handlenameChange}
                        />
                    </div>
                    <div className="form-element">
                        <label>
                            Enter LastName
                        </label>
                        <input type="text"
                        onChange={this.handleLastnameChange}
                        />
                    </div>
                    <button type="submit">Submit</button>
                </form>
                
            </div>
        )
    }
}

export default Controlled;