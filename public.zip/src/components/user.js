import React, { Component } from 'react';
import Formfields from '../widgets/Forms/Formsfields';

class User extends Component {

    state = {
        formdata:{
            name:{
                element:'input',
                value:'',
                label:true,
                labelText:'Name',
                config:{
                    name:'name_input',
                    text:'text',
                    placeholder:'Enter Your Name'
                },
                validation:{
                    required:true,
                    minlength:5
                },
                valid:false,
                touched:false,
                validationMessage:''
            },
            lastname:{
                element:'input',
                value:'',
                label:true,
                labelText:'LastName',
                config:{
                    name:'lastname_input',
                    text:'text',
                    placeholder:'Enter Your LastName'
                },
                validation:{
                    required:true,
                    minlength:5
                },
                valid:false,
                touched:false,
                validationMessage:''
            },
            message:{
                element:'textarea',
                value:'',
                label:true,
                labelText:'Message',
                config:{
                    name:'message_input',
                    rows:4,
                    cols:36
                },
                validation:{
                    required:false
                },
                valid:true
                
            },
            age:{
                element:'age',
                value:'',
                label:true,
                labelText:'Age',
                config:{
                    name:'Age_input',
                    option:[
                        {val:1,text:'10-20'},
                        {val:2,text:'20-30'},
                        {val:3,text:'30-80'}
                    ]
                },
                validation:{
                    required:false
                },
                valid:true
                
            }
        }
        
    }

    updateForm=(newState)=>{
        this.setState({
            formdata:newState
        })
    }

    submitForm=(event)=>{
        event.preventDefault();
        let dataToSubmit = {};
        let formdataa = true;

        for(let key in this.state.formdata){
            dataToSubmit[key] = this.state.formdata[key].value;
        }
        for(let key in this.state.formdata){
            formdataa = this.state.formdata[key].valid && formdataa
        }

        if(formdataa){
            console.log(dataToSubmit);
        }

        

    }

    render(){
        return(
            <div className="container">
                <form onSubmit={this.submitForm}>
                    <Formfields 
                    formdata={this.state.formdata}
                    onblur = {(newState) => this.updateForm(newState)}
                    change = {(newState) => this.updateForm(newState)}
                    />
                    <button type="submit">
                        Submit
                    </button>
                </form>
               
            </div>
        )
    }
}

export default User;