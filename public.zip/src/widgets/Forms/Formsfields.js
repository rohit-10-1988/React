import React from 'react';

function Formfields(props){
    
    function renderFields(){
        const formArray = [];
    
        for(let elementName in props.formdata){
            formArray.push({
                id:elementName,
                settings:props.formdata[elementName]
            })
        }

        return formArray.map((item,i)=>{
            return(
                <div key={i} className="from_element">
                    {renderTemplates(item)}
                </div>
            )
        });

    function showLabel(show,label){
    return show ? <label>{label}</label> : null;

    } 
    
    function changeHandler(event,id,blur){
        const newstate = props.formdata;
        newstate[id].value = event.target.value;

        if(blur){
            let validate = validation(newstate[id]);
            newstate[id].valid = validate[0];
            newstate[id].validationMessage = validate[1];
        }

        newstate[id].touched = true;

        props.change(newstate);
    }

    function validation(element){
        let error = [true,'']

        if(element.validation.minlength){
            const valid = element.value.length >= element.validation.minlength;
            const message = `${!valid ? 'Atleast 5 characters required' : ''}`

            error = !valid ? [valid,message]:error;
        }

        if(element.validation.required){
            const valid = element.value.trim() !== '';
            const message = `${!valid ? 'This cannot be blank' : ''}`

            error = !valid ? [valid,message]:error;
        }
        return error;
    }
    function showValidation(data){
        console.log(data);
        let errorMessage = null;
        if(data.validation && !data.valid){
            errorMessage = (
                <div className="error_label">
                    {data.validationMessage}
                </div>
            )
        }
        return errorMessage

    }
    
    function renderTemplates(data){
        let template = null;
        let values = data.settings;

            switch(values.element){
                case('input'):
                template = (
                        <div>
                            {showLabel(values.label,values.labelText)}
                            <input 
                            {...values.config}
                            value={values.value} 
                            onBlur = {
                                (event) => changeHandler(event,data.id,true)
                              }
                            onChange={
                                (event) => changeHandler(event,data.id,false)
                            } 
                            />
                            {showValidation(values)}
                        </div>
                    ) 
                break;
                case('textarea'):
                template = (
                        <div>
                            {showLabel(values.label,values.labelText)}
                            
                            <textarea
                            {...values.config}
                              value={values.value} 
                             
                              onChange={
                                  (event) => changeHandler(event,data.id,false)
                              }  
                            >

                            </textarea>
                        </div>
                    ) 
                break;
                case('age'):
                template = (
                        <div>
                            {showLabel(values.label,values.labelText)}
                            <select
                            name = {values.config.name}
                            value={values.value} 
                            onChange={
                                (event) => changeHandler(event,data.id)
                            } 
                            >
                                {values.config.option.map((item,i)=>{
                                    return <option key={i} value={item.val}>

                                            {item.text}
                                    </option>
                                })}

                            </select>
                        </div>
                    ) 
                break;
                default:
                template = null;
                
            }
            return template;
        }
    }   
    return(
        <div>
            {renderFields()}
        </div>
    )

}

export default Formfields;